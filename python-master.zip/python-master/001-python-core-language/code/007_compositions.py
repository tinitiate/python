## >---
## >YamlDesc: CONTENT-ARTICLE
## >Title: python convert dictionary to list, conver dictionary to tuple
## >MetaDescription: python read nested list dictionary tuple convert dictionary to list to tuple example code, tutorials
## >MetaKeywords: python convert dictionary to list, conver dictionary to tuple example code, tutorials
## >Author: Venkata Bhattaram / tinitiate.com
## >ContentName: composition
## >---

## ># PYTHON Convert Tuple to List to Dictionary
## >*
#convert 2 Lists to Dict
print(dict(zip([x for x in 'abcdefg'], xrange(1, 8))))