def mul2nums(num1, num2):
    print(num1*num2)